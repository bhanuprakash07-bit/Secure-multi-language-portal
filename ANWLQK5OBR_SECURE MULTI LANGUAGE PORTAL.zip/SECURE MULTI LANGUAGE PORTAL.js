const translations = {
    English: "Welcome",
    Spanish: "Bienvenido",
    Hindi: "स्वागत है",
    Portuguese: "Bem-vindo",
    Chinese: "欢迎",
    French: "Bienvenue"
};

let generatedOTP = "";

function changeLanguage() {

    const selectedLanguage = document.getElementById("languageSelect").value;

    if (selectedLanguage === "French") {

        // Generate 6 digit OTP
        generatedOTP = Math.floor(100000 + Math.random() * 900000).toString();

        alert("OTP Sent: " + generatedOTP); // For demo purpose

        document.getElementById("otpSection").classList.remove("hidden");
        document.getElementById("message").innerText = "OTP sent. Please verify.";

    } else {

        document.getElementById("title").innerText = translations[selectedLanguage];
        document.getElementById("message").innerText = "Language changed successfully!";
        document.getElementById("otpSection").classList.add("hidden");
    }
}

function verifyOTP() {

    const enteredOTP = document.getElementById("otpInput").value;

    if (enteredOTP === generatedOTP) {

        document.getElementById("title").innerText = translations["French"];
        document.getElementById("message").innerText = "French language activated successfully!";
        document.getElementById("otpSection").classList.add("hidden");

    } else {
        document.getElementById("message").innerText = "Invalid OTP. Try again.";
    }
}